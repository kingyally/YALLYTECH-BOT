const fs = require('fs-extra');
const { blazetz } = require(__dirname + "/../../devblaze/blazetz");
const s = require(__dirname + "/../../settings");
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);

// VCard Contact kwa quoting
const quotedContact = {
  key: {
    fromMe: false,
    participant: `0@s.whatsapp.net`,
    remoteJid: "status@broadcast"
  },
  message: {
    contactMessage: {
      displayName: "MSELA CHUI XMD VERIFIED ✅",
      vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:MSELA CHUI XMD VERIFIED ✅\nORG:𝐌𝐒𝐄𝐋𝐀-𝐂𝐇𝐔𝐈-𝐗𝐌𝐃 BOT;\nTEL;type=CELL;type=VOICE;waid=260774358600:+260774358600\nEND:VCARD"
    }
  }
};

blazetz({ nomCom: "payment", categorie: "General" }, async (dest, client, commandeOptions) => {
  let { repondre, mybotpic } = commandeOptions;

  let infoMsg = `┏━━━━━━━━━━━━━━━━━━\n` +
                `┃ 💳 *Payment Details*\n` +
                `┃ \n` +
                `┃ 👤 *Name:* ${s.OWNER_NAME}\n` +
                `┃ 📞 *Number:* +260774358600\n` +
                `┃ 🌐 *Method:* Online Payment\n` +
                `┃ 🌍 *Country:* Zambia 🇿🇲\n` +
                `┗━━━━━━━━━━━━━━━━━`;

  let lien = mybotpic() || "https://files.catbox.moe/0pfgz3.jpg";

  try {
    const imageType = lien.match(/\.(jpeg|jpg|png|gif|mp4)$/i)?.[0];

    const contextInfo = {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "120363405040601085@newsletter",
        newsletterName: "𝐌𝐒𝐄𝐋𝐀-𝐂𝐇𝐔𝐈-𝐗𝐌𝐃",
        serverMessageId: 1
      }
    };

    if (imageType?.includes('mp4') || imageType?.includes('gif')) {
      await client.sendMessage(dest, {
        video: { url: lien },
        caption: infoMsg,
        gifPlayback: true,
        contextInfo
      }, { quoted: quotedContact });
    } else {
      await client.sendMessage(dest, {
        image: { url: lien },
        caption: infoMsg,
        contextInfo
      }, { quoted: quotedContact });
    }

  } catch (e) {
    console.log("🥵 Menu error: " + e);
    repondre("🥵 Menu error: " + e.message);
  }
});
